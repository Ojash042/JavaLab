import javax.swing.*;

public class DefaultPanel extends JPanel {
}
