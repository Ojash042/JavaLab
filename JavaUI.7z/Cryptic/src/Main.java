// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        //Blake2 blake2 = new Blake2("hellowordl232".getBytes(),64);
        //byte[] bytes = blake2.convertIVToByteArray();
        //byte[] paramBytes = blake2.convertParamsToByteArray();
        //for(int i=0;i<paramBytes.length; i++){
        //    System.out.println(String.format("i: %d val:%02X",i, paramBytes[i]));
        //}
        Blake2b blake2b = new Blake2b();

    }
}