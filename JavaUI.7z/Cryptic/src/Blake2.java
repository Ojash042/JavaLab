import  java.lang.Integer;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.sql.Struct;
import java.util.Arrays;

public class Blake2 {
    private  byte[] message;
    private  byte[] digestSize;
    private byte[] inputParameter;

    private int[][] Sigma = new int[][]{
            { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15},
            {14,10, 4, 8, 9,15,13, 6, 1,12, 0, 2,11, 7, 5, 3},
            {11, 8,12, 0, 5, 2,15,13,10,14, 3, 6, 7, 1, 9, 4},
            {7, 9, 3, 1,13,12,11,14, 2, 6, 5,10, 4, 0,15, 8},
            {9, 0, 5, 7, 2, 4,10,15,14, 1,11,12, 6, 8, 3,13},
            {2,12, 6,10, 0,11, 8, 3, 4,13, 7, 5,15,14, 1, 9},
            {12, 5, 1,15,14,13, 4,10, 0, 7, 6, 3, 9, 2, 8,11},
            {13,11, 7,14,12, 1, 3, 9, 5, 0,15, 4, 8, 6, 2,10},
            {6,15,14, 9,11, 3, 0, 8,12, 2,13, 7, 1, 4,10, 5},
            {10, 2, 8, 4, 7, 6, 1, 5,15,11, 9,14, 3,12,13 ,0},
            {0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15},
            {14,10, 4, 8, 9,15,13, 6, 1,12, 0, 2,11, 7, 5, 3},
    };
    private final long[] initializationVectorHex =new long[]{
            0x6a09e667f3bcc908L,
            0xbb67ae8584caa73bL,
            0x3c6ef372fe94f82bL,
            0xa54ff53a5f1d36f1L,
            0x510e527fade682d1L,
            0x9b05688c2b3e6c1fL,
            0x1f83d9abfb41bd6bL,
            0x5be0cd19137e2179L,
    };
    private long[] stateVector = initializationVectorHex;
    private String parameterString = "0x";

    private interface DefaultParameter{
        byte digestLength = (byte) 64;
        byte keyLength = (byte) 0;
        byte[] salt = intToLittleEndian(0,16);
        byte[] personalization = intToLittleEndian(0,16);

        byte fanout = (byte) 2;
        byte maxDepth = (byte) 1;
        byte innerLength = (byte) 0;
        byte[] leafSize = intToLittleEndian(0,4);
        byte[] nodeOffset = intToLittleEndian(0,8);
        byte nodeDepth = (byte) 0;
        byte[] RFU = intToLittleEndian(0, 14);
    }

    public void hash(){
        parameterString += String.format("%2x",digestSize[0]) + "00" +"01"+"01";
    }

    public byte[] convertIVToByteArray(){
        ByteBuffer byteBuffer = ByteBuffer.allocate(64);
        for(long val: initializationVectorHex){
            byteBuffer.putLong(val);
        }
        return byteBuffer.array();
    }
    public byte[] convertParamsToByteArray(){
        byte[] byteArray = new byte[64];
        byteArray[0] = DefaultParameter.digestLength;
        byteArray[1] = DefaultParameter.keyLength;
        byteArray[2] = DefaultParameter.fanout;
        byteArray[3] = DefaultParameter.maxDepth;

        System.arraycopy(DefaultParameter.leafSize,0,byteArray,4,DefaultParameter.leafSize.length);
        System.arraycopy(DefaultParameter.nodeOffset,0,byteArray,8,DefaultParameter.nodeOffset.length);

        byteArray[16] = DefaultParameter.nodeDepth;
        byteArray[17] = DefaultParameter.innerLength;

        System.arraycopy(DefaultParameter.RFU,0,byteArray,18,DefaultParameter.RFU.length);

        System.arraycopy(DefaultParameter.salt,0,byteArray,32,DefaultParameter.salt.length);

        System.arraycopy(DefaultParameter.personalization,0,byteArray,48,DefaultParameter.personalization.length);
        return byteArray;
    }
    public Blake2(byte[] _message, int _digestSize){
        message = _message;
        digestSize = ByteBuffer.allocate(4).putInt(_digestSize).array();

        //create the input parameter for the blake2 Algorithm by converting into little Endian version
        ByteBuffer buffer = ByteBuffer.allocate(_message.length + digestSize.length);
        buffer.put(digestSize);
        buffer.put(message);
        inputParameter = buffer.array();
        inputParameter = Arrays.copyOfRange(inputParameter,3,inputParameter.length);
        byte[] littleEndianInputParameter = byteArrayToLittleEndian(inputParameter);

        // Convert the IV hex to byte array
        byte[] initializationVectorByte = convertIVToByteArray();
        byte[] paramByte = convertParamsToByteArray();

        
    }

    public static byte[] byteArrayToLittleEndian(byte[] byteArray){
        byte[] byteReversed = new byte[byteArray.length];

        for(int i=byteArray.length-1;i>=0;i--){
            byteReversed[byteArray.length-1-i] = byteArray[i];
        }
        return byteReversed;
    }
    public static byte[] intToLittleEndian(int n, int noOfBytes){
        byte[] byteArray = new byte[noOfBytes];
        for(int i=0;i<noOfBytes;i++){
            byteArray[0] = (byte) ((n>> 8*i )& 0xFF);
        constructor Socket.Socket(Proxy) is not applicable}

        return byteArray;
    }
    public byte[] getInputParameter() {
        return digestSize;
    }
}
