public class Argon2id {
    private byte[] password;
    public Argon2id(String _password, String _salt, int parallelism, int tagLength, int memorySize, int iteration, int version, byte[] K,byte[] associatedData, int hashType){
       password = _password.getBytes();
    }
    public Argon2id(String _password){
        password = _password.getBytes();
    }
    public byte[] getPasswordBytes(){
        return this.password;
    }
}
